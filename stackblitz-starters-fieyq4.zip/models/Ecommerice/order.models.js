import mogoose from 'mongoose';

const orderItemSchema = new mogoose.Schema({
  productId: {
    type: mogoose.Schema.Types.ObjectId,
    ref: 'Product',
  },
  quantity: {
    type: Number,
    required: true,
  },
});

const orderSchema = new mogoose.Schema(
  {
    oderPrice: {
      type: int,
      required: true,
    },
    customer: {
      type: mogoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    orderItems: {
      type: [orderItemSchema],
    },
    address: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      enum: ['PENDING', 'CANCELLED', 'DELIVERD'],
      default: 'PENDING',
    },
  },
  { timestamps }
);

export const Order = mogoose.model('Order', orderSchema);
