import mogoose from "magoose"
const catagorySchema=new mogoose.Schema({
name:{
  type:String,
  required:true
}

},{timestamps:true})


export const Category=mogoose.models("Category",catagorySchema)