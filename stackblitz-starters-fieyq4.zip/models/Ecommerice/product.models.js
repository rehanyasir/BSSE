import mogoose from "mongoose"
const productSchema=new mogoose.Schema({
  deccription:{
    type:String,
    required:true
  },
  name:{
    type:String,
    required:true
  },
  productImage:{
    type:String


  },
 price:{
   type:Number,
   default:0,
  },
  stock:{
    default:0,
    type:Number
  },
  category:{
    type:mogoose.Schema.Types.ObjectId,
    ref:"Catagroy",
    required:true,

  },
  Owner:{
    type:mogoose.Schema.Types.ObjectId,
    ref:"User"


  }


},{timestamps})



export const Product= mogoose.model("Product",productSchema)

