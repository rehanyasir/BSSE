// practice for data modelling
import mongoose from "mongoose"

 // mogoose help karta hay schema bananay me. our schema object k under hum data rhakte hen
const userSchema =new mongoose.Schema(
  {
    username:{
      type: String,
      required: true,
      unique: true,
      lowercase:true
    },
    email:{
      type:String,
      required:true,
      unique:true,
      lowecase:true

    },
    password:{
      type:String,
      required: [true,"password is required"]
    }



  },{timestamps:true}
)
// ye mongoose ka schema hay.mongoose ko export  karne ka aik taareeka hota hay . ye export karne ka tareeka hay.
export const User = mongoose.model("User",userSchema)


