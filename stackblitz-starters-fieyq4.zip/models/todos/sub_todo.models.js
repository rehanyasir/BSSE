import mogoose from "mongoose"
const subTodoSchema= new mogoose.Schema(
  {
    contend:{
      type: "String",
      required:true
    },
    complete:{
      type:Boolean,
      default:false
    },
    createdBy:{
      type:mogoose.Schema.Types.ObjectId,
      ref:"User"
    }


},{timestamps})

export const SubTodo =mongoose.model("SubTodo",subTodoSchema)